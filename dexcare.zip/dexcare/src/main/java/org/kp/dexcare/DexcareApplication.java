package org.kp.dexcare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DexcareApplication {

	public static void main(String[] args) {
		SpringApplication.run(DexcareApplication.class, args);
	}

}
